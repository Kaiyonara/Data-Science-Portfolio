my_message = "Hello World"
print(my_message)

animal_type = "cat"
print(animal_type)

human_age = 34
print(human_age)

weather = "bright and sunny"
print(weather)

my_age = 42
print(my_age / 42)

my_message = "Hello World"
print(my_message)

my_message = "Hello World, how are you?"
print(my_message)

my_message = "Hello World, how are you?"

# set the value of `this_message` to that of `my_message`
this_message = my_message
print(this_message)

my_message = "\tI should be shifted to the right"
print(my_message)

my_message = "I am on one line\nbut I'm on the next line"
print(my_message)

my_text = "She said \"Hello!\""
print(my_text)

my_message = 'What\'s your name?'
print(my_message)

add_two_numbers = 2 + 2
print(add_two_numbers)

multiply_two_numbers = 33 * 54
print(multiply_two_numbers)

multiply_three_numbers = 33 * 54 * 89
print(multiply_three_numbers)

wiyn = "What is your name?"
hoay = "How old are you?"
hmmit = "How many months is that?"

awiyn = 'My name is "Billy".'
ahoay = 30
ahmmit = 360

print(wiyn)
print(awiyn)
print(hoay)
print(ahoay)
#print(hmmit)
#print(ahmmit)

my_string = 'I am a data scientist.'
my_integer = 42
my_float = 3.14

print(my_string)
print(my_integer)
print(my_float)